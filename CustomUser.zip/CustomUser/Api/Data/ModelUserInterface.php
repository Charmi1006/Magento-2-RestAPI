<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */
namespace MagentoCoders\CustomUser\Api\Data;

/**
 * Class ModelUserInterface
 * @package MagentoCoders\CustomUser\Api\Data
 */
interface ModelUserInterface extends \Magento\Framework\Api\ExtensibleDataInterface
{
    /**#@+
     * Constants for keys of data array. Identical to the name of the getter in snake case
     */
    const ENTITY_ID   = 'entity_id';
    const FIRST_NAME  = 'first_name';
    const LAST_NAME   = 'last_name';
    const CREATED_AT  = 'created_at';
    const UPDATED_AT  = 'updated_at';
    /**#@-*/

    /**
     * Get ID
     *
     * @return int|null
     */
    public function getId();

    /**
     * Get FirstName
     *
     * @return string|null
     */
    public function getFirstName();

    /**
     * Get LastName
     *
     * @return string|null
     */
    public function getLastName();

    /**
     * Get CreatedAt
     *
     * @return string|null
     */
    public function getCreatedAt();

    /**
     * Get UpdatedAt
     *
     * @return string|null
     */
    public function getUpdatedAt();

    /**
     * Set ID
     *
     * @param int $id
     * @return $this
     */
    public function setId($id);

    /**
     * Set FirstName
     *
     * @param string $first_name
     * @return $this
     */
    public function setFirstName($first_name);

    /**
     * Set LastName
     *
     * @param string $last_name
     * @return $this
     */
    public function setLastName($last_name);

    /**
     * Set CreatedAt
     *
     * @param int $create_at
     * @return $this
     */
    public function setCreatedAt($create_at);

    /**
     * Set UpdatedAt
     *
     * @param int $updated_at
     * @return $this
     */
    public function setUpdatedAt($updated_at);

    /**
     * Retrieve existing extension attributes object or create a new one.
     *
     * @return \MagentoCoders\CustomUser\Api\Data\ModelUserExtensionInterface|null
     */
    public function getExtensionAttributes();

    /**
     * Set an extension attributes object.
     *
     * @param \MagentoCoders\CustomUser\Api\Data\ModelUserExtensionInterface $extensionAttributes
     * @return $this
     */
    public function setExtensionAttributes(
        \MagentoCoders\CustomUser\Api\Data\ModelUserExtensionInterface $extensionAttributes
    );
}
