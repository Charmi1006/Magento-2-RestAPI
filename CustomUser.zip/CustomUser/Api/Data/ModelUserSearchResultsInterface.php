<?php

namespace MagentoCoders\CustomUser\Api\Data;


use Magento\Framework\Api\SearchResultsInterface;

/**
 * Class ModelUserSearchResultsInterface
 * @package MagentoCoders\CustomUser\Api\Data
 */
interface ModelUserSearchResultsInterface extends SearchResultsInterface
{
    /**
     * Get user list.
     *
     * @return \MagentoCoders\CustomUser\Api\Data\ModelUserInterface[]
     */
    public function getItems();

    /**
     * Set user list.
     *
     * @param \MagentoCoders\CustomUser\Api\Data\ModelUserInterface[] $items
     * @return $this
     */
    public function setItems(array $items);
}
