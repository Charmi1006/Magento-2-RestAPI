<?php
namespace MagentoCoders\CustomUser\Api;

use Magento\Framework\Api\SearchCriteriaInterface;

/**
 * Class ModelUserRepositoryInterface
 * @package MagentoCoders\CustomUser\Api
 */
interface ModelUserRepositoryInterface
{

    /**
     * Retrieve UserInfo By given id.
     *
     * @param int $Id
     * @return \MagentoCoders\CustomUser\Api\Data\ModelUserInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getById($Id);
    /**
     * Save UserInfo.
     *
     * @param \MagentoCoders\CustomUser\Api\Data\ModelUserInterface $userinfo
     * @return \MagentoCoders\CustomUser\Api\Data\ModelUserInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function save(Data\ModelUserInterface $userinfo);
    /**
     * Retrieve UserInfo matching the specified searchCriteria.
     *
     * @param SearchCriteriaInterface $searchCriteria
     * @return \MagentoCoders\CustomUser\Api\Data\ModelUserSearchResultsInterface
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function getList(SearchCriteriaInterface $searchCriteria);

    /**
     * Delete UserInfo.
     *
     * @param \MagentoCoders\CustomUser\Api\Data\ModelUserInterface $userinfo
     * @return bool true on success
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function delete(Data\ModelUserInterface $userinfo);
    /**
     * Delete UserInfo by ID.
     *
     * @param int $Id
     * @return bool true on success
     * @throws \Magento\Framework\Exception\NoSuchEntityException
     * @throws \Magento\Framework\Exception\LocalizedException
     */
    public function deleteById($Id);
}
