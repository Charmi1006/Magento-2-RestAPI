<?php

namespace MagentoCoders\CustomUser\Model\ResourceModel;

use Magento\Framework\Model\ResourceModel\Db\AbstractDb;
/**
 * Class ModelUser
 * @package MagentoCoders\CustomUser\Model\ResourceModel
 */
class ModelUser extends AbstractDb
{
    /**
     * Post Abstract Resource Constructor
     * @return void
     */
    protected function _construct()
    {
        $this->_init('magentocoders_customuser', 'entity_id');
    }
}
