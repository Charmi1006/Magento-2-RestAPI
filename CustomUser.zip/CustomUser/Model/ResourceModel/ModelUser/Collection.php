<?php
namespace MagentoCoders\CustomUser\Model\ResourceModel\ModelUser;

use \Magento\Framework\Model\ResourceModel\Db\Collection\AbstractCollection;

/**
 * Class Collection
 * @package MagentoCoders\CustomUser\Model\ResourceModel\ModelUser
 */
class Collection extends AbstractCollection
{
    /**
     * Remittance File Collection Constructor
     * @return void
     */
    protected function _construct()
    {
        $this->_init(\MagentoCoders\CustomUser\Model\ModelUser::class, \MagentoCoders\CustomUser\Model\ResourceModel\ModelUser::class);
    }
}
