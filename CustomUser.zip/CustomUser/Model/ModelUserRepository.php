<?php
/**
 * Copyright © Magento, Inc. All rights reserved.
 * See COPYING.txt for license details.
 */

namespace MagentoCoders\CustomUser\Model;

use MagentoCoders\CustomUser\Api\ModelUserRepositoryInterface;
use MagentoCoders\CustomUser\Api\Data;
use MagentoCoders\CustomUser\Model\ResourceModel\ModelUser as ResourceModelUser;
use MagentoCoders\CustomUser\Model\ResourceModel\ModelUser\CollectionFactory as ModelUserCollectionFactory;
use Magento\Framework\Api\DataObjectHelper;
use Magento\Framework\Api\SearchCriteria\CollectionProcessorInterface;
use Magento\Framework\Exception\CouldNotDeleteException;
use Magento\Framework\Exception\CouldNotSaveException;
use Magento\Framework\Exception\NoSuchEntityException;
use Magento\Framework\Reflection\DataObjectProcessor;

/**
 * Class ModelUserRepository
 * @package MagentoCoders\CustomUser\Model
 */
class ModelUserRepository implements ModelUserRepositoryInterface
{
    /**
     * @var ResourceModelUser
     */
    protected $resource;

    /**
     * @var ModelUserFactory
     */
    protected $modelUserFactory;

    /**
     * @var ModelUserCollectionFactory
     */
    protected $blockCollectionFactory;

    /**
     * @var Data\ModelUserSearchResultsInterfaceFactory
     */
    protected $searchResultsFactory;

    /**
     * @var DataObjectHelper
     */
    protected $dataObjectHelper;

    /**
     * @var DataObjectProcessor
     */
    protected $dataObjectProcessor;

    /**
     * @var CollectionProcessorInterface
     */
    private $collectionProcessor;

    /**
     * @param ResourceModelUser $resource
     * @param ModelUserFactory $modelUserFactory
     * @param ModelUserCollectionFactory $blockCollectionFactory
     * @param Data\ModelUserSearchResultsInterfaceFactory $searchResultsFactory
     * @param DataObjectHelper $dataObjectHelper
     * @param DataObjectProcessor $dataObjectProcessor
     * @param CollectionProcessorInterface $collectionProcessor
     */
    public function __construct(
        ResourceModelUser $resource,
        ModelUserFactory $modelUserFactory,
        ModelUserCollectionFactory $blockCollectionFactory,
        Data\ModelUserSearchResultsInterfaceFactory $searchResultsFactory,
        DataObjectHelper $dataObjectHelper,
        DataObjectProcessor $dataObjectProcessor,
        CollectionProcessorInterface $collectionProcessor
    ) {
        $this->resource               = $resource;
        $this->modelUserFactory       = $modelUserFactory;
        $this->blockCollectionFactory = $blockCollectionFactory;
        $this->searchResultsFactory   = $searchResultsFactory;
        $this->dataObjectHelper       = $dataObjectHelper;
        $this->dataObjectProcessor    = $dataObjectProcessor;
        $this->collectionProcessor    = $collectionProcessor;
    }

    /**
     * {@inheritdoc}
     */
    public function save(Data\ModelUserInterface $userinfo)
    {

        try {
            $this->resource->save($userinfo);
        } catch (\Exception $exception) {
            throw new CouldNotSaveException(__($exception->getMessage()));
        }
        return $userinfo;
    }

    /**
     * {@inheritdoc}
     */
    public function getById($Id)
    {
        $block = $this->modelUserFactory->create();
        $this->resource->load($block, $Id);
        if (!$block->getId()) {
            throw new NoSuchEntityException(__('The CMS block with the "%1" ID doesn\'t exist.', $Id));
        }
        return $block;
    }

    /**
     * {@inheritdoc}
     */
    public function getList(\Magento\Framework\Api\SearchCriteriaInterface $searchCriteria)
    {
        $collection = $this->blockCollectionFactory->create();

        $this->collectionProcessor->process($searchCriteria, $collection);

        /** @var Data\ModelUserSearchResultsInterface $searchResults */
        $searchResults = $this->searchResultsFactory->create();
        $searchResults->setSearchCriteria($searchCriteria);
        $searchResults->setItems($collection->getItems());
        $searchResults->setTotalCount($collection->getSize());
        return $searchResults;
    }

    /**
     * {@inheritdoc}
     */
    public function delete(Data\ModelUserInterface $userinfo)
    {
        try {
            $this->resource->delete($userinfo);
        } catch (\Exception $exception) {
            throw new CouldNotDeleteException(__($exception->getMessage()));
        }
        return true;
    }

    /**
     * {@inheritdoc}
     */
    public function deleteById($blockId)
    {
        return $this->delete($this->getById($blockId));
    }
}
