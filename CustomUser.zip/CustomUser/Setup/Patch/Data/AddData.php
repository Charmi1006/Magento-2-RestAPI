<?php

namespace MagentoCoders\CustomUser\Setup\Patch\Data;

use Magento\Framework\Setup\Patch\DataPatchInterface;
use MagentoCoders\CustomUser\Model\ModelUser;
use Magento\Framework\Setup\Patch\PatchVersionInterface;
use Magento\Framework\Module\Setup\Migration;
use Magento\Framework\Setup\ModuleDataSetupInterface;

/**
 * Class AddData
 * @package MagentoCoders\CustomUser\Setup\Patch\Data
 */
class AddData implements DataPatchInterface, PatchVersionInterface

{
    /**
     * @var ModelUser
     */
    private $modelUser;

    /**
     * @param ModelUser $modelUser
     */
    public function __construct(
        ModelUser $modelUser
    ) {
        $this->modelUser = $modelUser;
    }


    /**

     * {@inheritdoc}

     * @SuppressWarnings(PHPMD.ExcessiveMethodLength)

     */

    public function apply()

    {

        $authorData = [];

        $authorData['first_name'] = "Parmar";

        $authorData['last_name'] = "Girish";

        $this->modelUser->addData($authorData);

        $this->modelUser->getResource()->save($this->modelUser);
    }


    /**

     * {@inheritdoc}

     */

    public static function getDependencies()

    {
        return [];
    }


    /**

     * {@inheritdoc}

     */

    public static function getVersion()

    {
        return '2.0.1';
    }

    /**

     * {@inheritdoc}
     */

    public function getAliases()
    {
        return [];
    }
}
